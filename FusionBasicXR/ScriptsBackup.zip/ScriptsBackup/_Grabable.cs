using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Fusion.XR
{
    public enum TwoHandedMode
    {
        None = 0,
        AttachHand = 1,
        Average = 2
    }

    public class Grabable : MonoBehaviour
    {
        public TwoHandedMode twoHandedMode = TwoHandedMode.None;
        public bool isGrabbed;
        public float releaseThreshold = 0.4f;
        [SerializeField] private Transform[] grabPoints;

        private FusionXRHand attachedHand;
        private FusionXRHand attachedHand2;

        private Rigidbody rigidbody;

        //If 2 Handed:
        private Vector3 posOffset;
        private Vector3 rotOffset;

        #region UnityFunctions
        void Start()
        {
            rigidbody = GetComponent<Rigidbody>();
            gameObject.tag = "Grabable";
        }

        private void FixedUpdate()
        {
            if (!isGrabbed)
                return;

            if(twoHandedMode == TwoHandedMode.Average)
            {
                Vector3 avgPos;
                Quaternion avgRot;

                if(attachedHand2 != null)
                {
                    avgPos = Vector3.Lerp(attachedHand.transform.position, attachedHand2.transform.position, .5f);
                    avgRot = Quaternion.Lerp(attachedHand.transform.rotation, attachedHand2.transform.rotation, .5f);
                }
                else
                {
                    avgPos = attachedHand.transform.position;
                    avgRot = attachedHand.transform.rotation;
                }

                TrackPositionVelocity(avgPos);
                TrackRotationVelocity(avgRot);
            }
        }
        #endregion

        #region Events
        public TwoHandedMode Grab(FusionXRHand hand) 
        {
            Physics.IgnoreCollision(hand.GetComponent<Collider>(), GetComponent<Collider>(), true);
            //If the grabbing Hand is the second Hand and should be attached
            if (twoHandedMode == TwoHandedMode.AttachHand && isGrabbed)
            {
                attachedHand2 = hand;

                isGrabbed = true;
            }
            //If the grabbing hand is the second hand and the grab should be averaged
            else if(twoHandedMode == TwoHandedMode.Average)
            {
                if (isGrabbed)
                    attachedHand2 = hand;
                else
                    attachedHand = hand;

                isGrabbed = true;
            }
            //If the Hand is the first one and the Grab should be switched OR if the grab is the first one OR if the grab is the first one (main grip of a "AttachHand" Grabbable) only the second grip should return the AttachHand GripMode because only the second hand gets attached
            else
            {
                attachedHand?.Release();
                attachedHand = hand;

                isGrabbed = true;
                return TwoHandedMode.None;
            }
            return twoHandedMode;
        }

        public void Release(FusionXRHand hand)
        {
            Physics.IgnoreCollision(hand.GetComponent<Collider>(), GetComponent<Collider>(), false);
            //If second hand let go
            if (attachedHand2 == hand)
            {
                attachedHand2 = null;
            }
            //If first hand let go and there is a secondary hand
            else if(attachedHand == hand && attachedHand2 != null)
            {
                attachedHand = attachedHand2;
                attachedHand2 = null;
            }
            //If last Hand let go
            else
            {
                rigidbody.collisionDetectionMode = CollisionDetectionMode.Discrete;
                rigidbody.interpolation = RigidbodyInterpolation.None;
                isGrabbed = false;
                attachedHand = null;
                attachedHand2 = null;
            }
        }

        #endregion

        #region Functions
        public bool TryGetClosestGrapPoint(Vector3 point, out Transform GrapPoint)
        {
            GrapPoint = ClosestTransform(grabPoints, point);

            return GrapPoint != null;
        }

        Transform ClosestTransform(Transform[] transforms, Vector3 point)
        {
            Transform closestTransform = null;
            float distance = float.MaxValue;

            if (transforms != null)
            {
                foreach (Transform currentTransform in transforms)
                {
                    if ((currentTransform.position - point).sqrMagnitude < distance)
                    {
                        closestTransform = currentTransform;
                        distance = (currentTransform.position - point).sqrMagnitude;
                    }
                }
            }
            return closestTransform;
        }

        void TrackPositionVelocity(Vector3 targetPos /*, Transform followObj*/)
        {
            //var posWithOffset = followObj.TransformPoint(positionOffset);

            var positionDelta = targetPos - transform.position;

            Vector3 velocityTarget = (positionDelta * 60f);

            if (float.IsNaN(velocityTarget.x) == false)
            {
                rigidbody.velocity = Vector3.MoveTowards(rigidbody.velocity, velocityTarget, 20f);
            }
        }

        void TrackRotationVelocity(Quaternion targetRot)
        {
            //var rotWithOffset = targetRot * Quaternion.Euler(rotationOffset);

            Quaternion deltaRotation = targetRot * Quaternion.Inverse(transform.rotation);

            deltaRotation.ToAngleAxis(out var angle, out var axis);

            if (angle > 180f)
            {
                angle -= 360;
            }

            if (angle != 0)
            {
                Vector3 angularTarget = angle * axis * Mathf.Deg2Rad;
                if (float.IsNaN(angularTarget.x) == false) 
                {
                    angularTarget = (angularTarget * 50);
                    rigidbody.angularVelocity = Vector3.MoveTowards(rigidbody.angularVelocity, angularTarget, 10f);
                }
            }
        }
        #endregion

        #region Deprecated Functions
        Vector3 CalculateOffset()
        {
            Vector3 offset = Vector3.zero;

            if (grabPoints.Length > 0)
            {
                Transform grabPoint = ClosestTransform(grabPoints, attachedHand.transform.position);

                offset = grabPoint.position - transform.position;
            }
            else
            {
                offset = transform.position - attachedHand.transform.position;
            }

            return offset;
        }

        Vector3 CalculateRotationOffset()
        {
            Vector3 rotationOffset;

            if (grabPoints.Length > 0)
            {
                Transform grabPoint = ClosestTransform(grabPoints, attachedHand.transform.position);

                rotationOffset = grabPoint.eulerAngles;
            }
            else
            {
                rotationOffset = attachedHand.transform.eulerAngles - transform.eulerAngles;
            }

            return rotationOffset;
        }


        #endregion
    }
}
