using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

namespace Fusion.XR
{
    public enum Hand
    {
        Left = 0,
        Right = 1
    }

    public enum TrackingMode
    {
        Kinematic = 0,
        Velocity = 1,
        //Force = 2
    }

    public enum GrabMode
    {
        Kinematic = 0,
        Joint = 1,
        //Velocity = 2,
    }

    public class FusionXRHand : MonoBehaviour
    {

        #region Variables

        //Tracking
        public Hand hand;
        public Transform trackedController;
        private Transform followObject;

        public Vector3 positionOffset;
        public Vector3 rotationOffset;

        public TrackingMode trackingMode;

        private Vector3 targetPosition;
        private Quaternion targetRotation;
        private Rigidbody rigidbody;

        //Velocity Tracking
        public float positionStrength = 15f;
        public float rotationStrength = 30;

        //Inputs
        public InputActionReference grabReference;
        public InputActionReference pinchReference;

        //Grabbing
        public float grabRange = 0.1f;

        public GrabMode grabMode;

        [SerializeField] private Transform palm;
        [SerializeField] private float reachDist = 0.1f, joinDist = 0.05f;

        private bool isGrabbing;
        private Grabable grabbedObject;
        private Transform grabPoint;
        private Rigidbody targetBody;
        private FixedJoint joint1, joint2;

        private TwoHandedMode twoHandedMode;

        #endregion

        #region Start and Update
        void Start()
        {
            rigidbody = GetComponent<Rigidbody>();
            followObject = trackedController;

            grabReference.action.started += OnGrabbed;
            grabReference.action.canceled += OnLetGo;

            pinchReference.action.started += OnPinched;
            pinchReference.action.canceled += OnPinchedCancelled;
        }

        void Update()
        {
            targetPosition = followObject.position;
            targetRotation = followObject.rotation;

            switch ((int)trackingMode)
            {
                case 0:             //Case: kinematic tracking
                    TrackPositionKinematic(targetPosition);
                    TrackRotationKinematic(targetRotation.eulerAngles);
                    break;
                case 1:             //Case: velocity tracking;
                    TrackRotationVelocity(targetRotation);
                    TrackPositionVelocity(targetPosition, followObject);
                    break;
            }
            if(twoHandedMode == TwoHandedMode.AttachHand && grabbedObject != null)
            {
                if(Vector3.Distance(grabbedObject.transform.position, transform.position) > grabbedObject.releaseThreshold)
                {
                    grabbedObject.Release(this);
                }
            }
        }

        #endregion

        #region Events 
        //Grab Event Called if Grab Action is performed
        void OnGrabbed(InputAction.CallbackContext obj)
        {
            if (isGrabbing || (bool)grabbedObject)
            {
                return;
            }

            GameObject closestGrabable = ClosestGrabable(out Collider closestColl);

            if (closestGrabable == null)
                return;

            //Possible TODO: Add Check for Parent Rigidbody
            if (closestGrabable.TryGetComponent(out Rigidbody objectRigidbody))
            {
                grabbedObject = closestGrabable.GetComponent<Grabable>();

                targetBody = objectRigidbody;
            }
            else
            {
                return;
            }

            if(grabbedObject.TryGetClosestGrapPoint(transform.position, out Transform grabPoint))
            {
                StartCoroutine(GrabObject(closestColl, grabPoint));
            }
            else
            {
                StartCoroutine(GrabObject(closestColl));
            }
        }

        void OnLetGo(InputAction.CallbackContext obj)
        {
            Release();
        }

        void OnPinched(InputAction.CallbackContext obj)
        {

        }

        void OnPinchedCancelled(InputAction.CallbackContext obj)
        {

        }

        #endregion

        #region Functions
        //Always with a defined GrabPoint, if there is none, overload will generate one
        IEnumerator GrabObject(Collider closestColl, Transform grabPoint)
        {
            isGrabbing = true;
            twoHandedMode = grabbedObject.Grab(this);

            //Move to Grab Point
            if(twoHandedMode != TwoHandedMode.Average)
            {
                followObject = grabPoint;

                //Reach Grab Point
                while (isGrabbing && Vector3.Distance(grabPoint.position, palm.position) > joinDist)
                {
                    yield return new WaitForEndOfFrame();
                }
            }

            //Freeze
            rigidbody.velocity = Vector3.zero;
            rigidbody.angularVelocity = Vector3.zero;
            targetBody.velocity = Vector3.zero;
            targetBody.angularVelocity = Vector3.zero;

            //targetBody.collisionDetectionMode = CollisionDetectionMode.Continuous;
            //targetBody.interpolation = RigidbodyInterpolation.Interpolate;

            //Joints
            if (twoHandedMode == TwoHandedMode.None)
            {
                joint1 = gameObject.AddComponent<FixedJoint>();
                joint1.connectedBody = targetBody;
                joint1.breakForce = float.PositiveInfinity;
                joint1.breakTorque = float.PositiveInfinity;

                joint1.connectedMassScale = 1;
                joint1.massScale = 1;
                joint1.enableCollision = false;
                joint1.enablePreprocessing = false;

                joint2 = targetBody.gameObject.AddComponent<FixedJoint>();
                joint2.connectedBody = rigidbody;
                joint2.breakForce = float.PositiveInfinity;
                joint2.breakTorque = float.PositiveInfinity;

                joint2.connectedMassScale = 1;
                joint2.massScale = 1;
                joint2.enableCollision = false;
                joint2.enablePreprocessing = false;
            }
            else if(twoHandedMode == TwoHandedMode.AttachHand)
            {
                //Attach RenderHand

            }
            else if(twoHandedMode == TwoHandedMode.Average)
            {
                //Attach RenderHand
            }

            followObject = trackedController;
        }

        //If no GrabPoint is set;
        IEnumerator GrabObject(Collider closestColl)
        {
            //Grab Point
            grabPoint = new GameObject().transform;
            grabPoint.position = closestColl.ClosestPoint(palm.position);
            grabPoint.parent = grabbedObject.transform;

            StartCoroutine(GrabObject(closestColl, grabPoint));

            yield return null;
        }

        //As a function so it can also be called from a grabbable that wants to switch hands
        public void Release()
        {
            isGrabbing = false;
            followObject = trackedController;

            if (joint1 != null)
                Destroy(joint1);
            if (joint2 != null)
                Destroy(joint2);
            if (grabPoint != null)
            {
                Destroy(grabPoint.gameObject);
            }

            if(grabbedObject != null)
                grabbedObject.Release(this);

            if (grabbedObject != null)
            {
                grabPoint = null;
                grabbedObject = null;
            }
        }

        GameObject ClosestGrabable(out Collider closestColl)
        {
            //find all close Colliders
            Collider[] nearObjects = Physics.OverlapSphere(palm.position, reachDist);

            GameObject ClosestGameObj = null;
            closestColl = null;
            float Distance = float.MaxValue;

            //Check for the closest Grabbable Object
            if (nearObjects != null)
            {
                foreach (Collider coll in nearObjects)
                {
                    if(coll.gameObject.tag == "Grabable")
                    {
                        if ((coll.transform.position - transform.position).sqrMagnitude < Distance)
                        {
                            closestColl = coll;
                            ClosestGameObj = coll.gameObject;
                            Distance = (coll.transform.position - transform.position).sqrMagnitude;
                        }
                    }
                }
            }
            return ClosestGameObj;
        }

        void TrackPositionVelocity(Vector3 targetPos, Transform followObj)
        {
            var posWithOffset = followObj.TransformPoint(positionOffset);

            var vel = (posWithOffset - transform.position).normalized * positionStrength * Vector3.Distance(posWithOffset, transform.position);
            rigidbody.velocity = vel;
        }

        void TrackRotationVelocity(Quaternion targetRot)
        {
            var rotWithOffset = targetRot * Quaternion.Euler(rotationOffset);


            Quaternion deltaRotation = rotWithOffset * Quaternion.Inverse(transform.rotation);

            deltaRotation.ToAngleAxis(out var angle, out var axis);
            
            if (angle > 180f)
            {
                angle -= 360;
            }

            if(Mathf.Abs(axis.magnitude) != Mathf.Infinity)
                rigidbody.angularVelocity = axis * (angle * rotationStrength * Mathf.Deg2Rad);
        }

        void TrackPositionKinematic(Vector3 targetPos)
        {
            transform.position = targetPos;
        }

        void TrackRotationKinematic(Vector3 targetRot)
        {
            transform.eulerAngles = targetRot;
        }
        #endregion
    }
}
